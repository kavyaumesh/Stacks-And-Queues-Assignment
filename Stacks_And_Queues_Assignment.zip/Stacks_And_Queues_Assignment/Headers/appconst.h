#include <stdlib.h>
#include <stdio.h>
#ifndef APPCONSTANT_H_INCLUDED
#define APPCONSTANT_H_INCLUDED
#define MAX_DEPTH 32

#define STACK_OK 1
#define STACK_EMPTY 2
#define STACK_FULL 3

#endif // APPCONSTANT_H_INCLUDED
