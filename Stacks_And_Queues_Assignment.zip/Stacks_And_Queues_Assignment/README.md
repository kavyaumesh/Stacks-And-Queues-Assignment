# StackAndQueues
Assignments Stacks and Queues

1. Check balancing of symbols (like ‘{‘, ‘(‘, ‘[‘ ) and their order using stack.

2. Evaluate postfix expression using stack.  Example: postfix fix expression is 6 5 2 3 + 8 * + 3 + * 
   Hint: When number is seen, it is pushed onto the stack; when an operator is seen, the operator is applied to the two numbers that are
         popped from the stack, and the result is pushed onto the stack.


